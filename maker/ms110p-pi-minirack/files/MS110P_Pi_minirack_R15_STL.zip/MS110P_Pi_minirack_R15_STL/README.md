# MS110P와 Raspberry Pi용 3D 출력 미니랙 · R15 STL

MERCUSYS MS110P 위에 Raspberry Pi를 세로로 꽂는 독립형 미니랙의 출력용 STL 7종이다. 부품표, 출력 조건, 조립 순서와 검증 범위는 이 페이지에 있다.

https://hughqlee.com/maker/ms110p-pi-minirack/

| 파일 | 출력 수량 (Pi 3B+ 2대 + Zero 2 W 1대 예시) |
|---|---:|
| stl/P01_base_switch_cradle.stl | 1 |
| stl/P02_side_frame_L.stl | 1 |
| stl/P02_side_frame_R.stl | 1 |
| stl/P03_Pi_deck_five_guides.stl | 1 |
| stl/P04_carrier_SD_nail.stl | 2 |
| stl/P08_Zero2_PoE_carrier.stl | 1 |
| stl/P09_L_roof_rear_cover.stl | 1 |

STL 단위는 mm이고, 부품별 출력 자세와 바닥 Z=0이 적용되어 있다. 슬라이서에서 100%로 가져온다. 캐리어 한 개로 레일 끼움부터 확인한 뒤 나머지를 출력한다. 정밀 끼움, 강도, 덮개를 씌운 상태의 PoE 전력·온도와 장기 운용은 시험하지 않았다.

## 라이선스

자체 제작한 3D 모델과 문서는 CC BY 4.0으로 공개한다(LICENSE). 재사용할 때는 출처와 라이선스 링크를 표시하고 변경 사항을 밝힌다. 예: "MS110P와 Raspberry Pi용 3D 출력 미니랙 R15, Hugh Q Lee (https://hughqlee.com/maker/ms110p-pi-minirack/), CC BY 4.0". 제3자 자료는 원권리자의 이용 조건을 따른다(THIRD_PARTY_NOTICES.md). 제품명과 상표는 호환 대상을 알리기 위한 것이며, 제조사의 제작·제휴·승인을 뜻하지 않는다.

파일 무결성은 SHA256SUMS.txt로 확인한다: `shasum -a 256 -c SHA256SUMS.txt`

---

# 3D-printed mini rack for MS110P and Raspberry Pi · R15 STL

The seven print-ready STL files of a standalone mini rack that stands Raspberry Pi boards upright on top of a MERCUSYS MS110P. The parts list, print settings, assembly steps, and what has and has not been tested are on this page:

https://hughqlee.com/maker/en/ms110p-pi-minirack/

The STL files are in millimeters, saved in their print orientation with the bed at Z=0. Import them at 100%. Print one carrier and check its fit on the rail before printing the rest. Precise fit, strength, PoE power and temperature with the cover on, and long-term operation have not been tested.

The original 3D models and documentation are released under CC BY 4.0 (LICENSE). When you reuse them, credit the source, link the license, and say what you changed, for example: "3D-printed mini rack for MS110P and Raspberry Pi R15, Hugh Q Lee (https://hughqlee.com/maker/en/ms110p-pi-minirack/), CC BY 4.0". Third-party materials keep their owners' terms (THIRD_PARTY_NOTICES.md, in Korean). Product names and trademarks only identify compatible hardware and do not imply that any manufacturer made, endorsed, or is affiliated with this work.
