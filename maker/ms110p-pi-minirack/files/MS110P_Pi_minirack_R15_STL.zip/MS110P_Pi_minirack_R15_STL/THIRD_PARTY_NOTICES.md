# 제3자 자료 안내

자체 제작한 3D 모델과 문서는 **[CC BY 4.0](https://creativecommons.org/licenses/by/4.0/)**으로 공개하며, **제3자 자료는 원권리자의 이용 조건을 따른다.** 이 패키지의 라이선스 선언으로 제조사 원자료나 상표를 재허락하지 않는다.

## 자체 제작물

랙 출력 부품 P01·P02 L/R·P03·P04·P08·P09와 해당 모델·문서는 자체 제작물이다. 전자부품 참조는 보드 외곽·홀·포트 경계 치수를 바탕으로 박스와 원통 등으로 직접 만든 간섭 확인용 프록시다. 제조사 STEP 메시를 그대로 가져온 전자부품 형상으로 표시하지 않는다. 참조는 출력 부품과 구분하며 실제 제품의 상세 형상이나 완성 적층 실측값을 보증하지 않는다.

## 제조사 참조

| 대상 | 참고한 내용 | 원자료 포함 여부 | 공식 출처 |
|---|---|---|---|
| MERCUSYS MS110P | 외곽 규격·포트·제품 사양 | 원자료 미포함 | [제품 사양](https://www.mercusys.com/en/product/details/ms110p/) |
| Raspberry Pi 3B+·PoE+ HAT | 보드 외곽·홀·적층 참고 | 원자료 미포함 | [Pi 3B+ 도면](https://datasheets.raspberrypi.com/rpi3/raspberry-pi-3-b-plus-mechanical-drawing.pdf), [PoE+ HAT](https://datasheets.raspberrypi.com/poe/poe-plus-hat-product-brief.pdf) |
| Raspberry Pi Zero 2 W | 보드 외곽·장착홀 | 원자료 미포함 | [기구 도면](https://datasheets.raspberrypi.com/rpizero2/raspberry-pi-zero-2-w-mechanical-drawing.pdf) |
| Waveshare PoE/ETH/USB HUB HAT | 보드·스페이서·포트 경계 치수 | STEP·사진 원문 미포함 | [제품](https://www.waveshare.com/poe-eth-usb-hub-hat.htm), [제조사 3D 자료](https://files.waveshare.com/wiki/PoE_ETH_USB_HUB_HAT/poe-eth-usb_hub_hat_3d_drawing.zip) |

Raspberry Pi 자료는 파일 유형에 따라 라이선스가 다르므로 [제조사 안내](https://www.raspberrypi.com/licensing/)와 개별 파일 표시를 확인한다. 확보한 Waveshare STEP에는 별도 재배포 라이선스가 확인되지 않아 원문을 동봉하지 않았다. 공식 사이트에서 내려받을 수 있다는 사실만으로 재배포 허가가 있는 것으로 취급하지 않는다.

제품명·상표는 호환 대상을 식별하기 위한 것이다. 제조사의 공식 제작·제휴·승인을 의미하지 않는다. 향후 제조사 원자료를 포함할 때는 허용된 범위를 확인하고 해당 자료의 라이선스·출처·변경 여부를 함께 기록한다.

## 라이선스 원문 출처

[LICENSE](LICENSE)는 Creative Commons Attribution 4.0 International의 전문이며, [SPDX의 CC-BY-4.0 텍스트](https://raw.githubusercontent.com/spdx/license-list-data/main/text/CC-BY-4.0.txt)를 변경하지 않고 수록했다. 공식 라이선스 주소는 [Creative Commons CC BY 4.0](https://creativecommons.org/licenses/by/4.0/legalcode)이다.
